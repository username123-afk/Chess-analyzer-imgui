# chess-analyzer-overlay

Native ARM64 Android root executable using Dear ImGui/OpenGL ES and a SurfaceComposer-backed native window.

Pipeline: root screen capture -> board detection -> template recognition -> FEN -> local Stockfish UCI -> best-move overlay.

## Runtime

The executable expects:
- `/data/local/tmp/stockfish-android-arm64`
- writable `/data/adb/chess_analyzer/run`
- optional learned templates at `/data/adb/chess_analyzer/run/templates.bin`

Run:

```sh
su
chmod 755 /data/local/tmp/chess-analyzer-overlay
chmod 755 /data/local/tmp/stockfish-android-arm64
/data/local/tmp/chess-analyzer-overlay
```

## Vision templates

The recognizer can learn from a standard starting-position screenshot. This is deliberate: piece artwork differs between chess themes. The uploaded `vision.cpp`/`vision.h` implementation is integrated directly and is used for board detection, square analysis, template learning, recognition and orientation.

## Important chess-state limitation

A single screenshot proves piece placement but cannot prove side-to-move, castling rights, or en-passant state. The UI therefore exposes side-to-move and the implementation defaults castling/en-passant conservatively. Stockfish is only invoked after a structurally valid position is produced; it does not receive a fabricated board layout.

## Build

GitHub Actions installs Android NDK/CMake, fetches Dear ImGui and the native-window helper, builds the ARM64 executable, and builds Stockfish separately. This sandbox does not contain an Android NDK/sysroot, so an Android ARM64 ELF cannot be honestly claimed as locally compiled here.
